#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

typedef struct {

  int       resnr;
  int       nratoms;
  int       *atoms;
  real      charge;

} t_residue;

typedef struct {

  t_residue  residue;    /* the qhoppable particle itself */

  int        nrdonors;   
  t_residue  *donors;    /* array of potential donors */

  int        nracceptors;
  t_residue  *acceptors; /* array of potential acceptors */

  int        nrdonaccs;
  t_residue  *donaccs;   /* array of donors and acceptors */

  int	    lasthoppingtime;  /* utako: proton last hopin time, actually it
			       * is the step.
			       */
  
} t_qhopresidue;

typedef struct {

  int           qhopfreq; /* frequecency at which to try to do qhops. */
  int           qhopwait; /* utako: after a hop, integration step 
			   * to wait until next hop 
			   */
  int           nrqhopresidues;
  t_qhopresidue *qhopresidues;
  bool          tryhop;
  bool bverbose;  
} t_qhoprec;


