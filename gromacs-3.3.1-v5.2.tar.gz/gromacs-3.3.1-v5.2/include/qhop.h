#ifndef _qhop_h
#define _qhop_h


#ifdef HAVE_IDENT
#ident	"@(#) qhop.h 1 28/2/01"
#endif /* HAVE_IDENT */
#include "typedefs.h"
#include "pbc.h"
#include "nsb.h"
#include "network.h"
#include "tgroup.h"

#define DOO            0.35
#define HBOND          0.2
#define HOPANG         120
#define TOL             10
#define BONDCRITERIUM 0.12
#define CLUSTERRAD 1.0

typedef struct{
  int don;
  real prob;
  int acc;
  int prot;
  t_residue *acceptor;
  t_residue *donor;
  int qhopresidues_idx; /* utako: to remember where this donor from the list of qhoprec */
} t_hop;

typedef struct{
  
  real alpha, beta, gamma;
  real  k_1, k_2, k_3, m_1, m_2, m_3;
  real  s_A, t_A, v_A, s_B, s_C, t_C, v_C;
  real  f, g, h;
  real  p_1, q_1, q_2, q_3, r_1, r_2, r_3;


} t_qhop_parameters;


     
extern t_qhoprec *mk_qhoprec(void);

extern void init_qhoprec(t_commrec *cr,
			 matrix box,
			 t_topology *top,
			 t_inputrec *ir,
			 t_forcerec *fr);

extern void update_qhoprec(t_commrec *cr,
			   t_forcerec *fr,
			   rvec x[],
			   t_mdatoms *md,
			   matrix box,
			   t_topology *top);

extern bool do_qhop(FILE *fplog, 
		    int step, 
		    t_forcerec *fr, 
		    t_inputrec *ir, 
		    t_nsborder *nsb, 
		    t_commrec *cr,
		    t_commrec *mcr,
		    t_nrnb *nrnb, 
		    t_groups *grps, 
		    t_mdatoms *mdatoms,
		    rvec x[],
		    matrix box, 
		    real lambda,
		    //rvec mu_tot[],
		    t_topology *top, 
		    real ener[],
		    t_graph *graph,
		    t_fcdata *fcd,
		    t_state *state);






#endif	/* _qhop_h */

