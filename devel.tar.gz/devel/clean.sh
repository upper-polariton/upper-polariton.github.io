find . -name "*.o" -exec rm -f {} \;
find . -name "*.f" -exec rm -f {} \;
find . -name "*.exe" -exec rm -f {} \;
