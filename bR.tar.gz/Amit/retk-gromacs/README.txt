
===================================================================================
= Gromacs topology of a retinal attached to a lysine via a protonated Schiff base =
===================================================================================

These files generate a GROMACS topology of a retinal attached to a lysine, for a simulation
using the AMBER99SB*-ILDN force field. Hydrogens may or may not be described as virtual sites.
The retinal is in the all-trans state.

These files come without any warranty of any kind. Check the topology carefully before using it.
If you find a bug, please report it to Jochen Hub (jhub@gwdg.de).

The retinal parameters come originally from Hayashi et al. (see below) and were
converted to Gromacs format by Jochen Hub. The AMBER99SB*-ILDN files were
take from the Gromacs user contributions in November 2012. If you use
these files for publication, please cite (in addition to the AMBER references):

Time-Resolved WAXS Reveals Accelerated Conformational Changes in Iodoretinal-Substituted Proteorhodopsin 
Erik Malmerberg, Zaid Omran, Jochen S. Hub, Xuewen Li, Gergely Katona,
Sebastian Westenhoff, Linda Johansson, Magnus Andersson, Marco
Cammarata, Michael Wulff, David van der Spoel, Jan Davidsson,
Alexandre Specht, Richard Neutze 
Biophys. J. 101, 1245-1353 (2011)

Structural Changes during the Formation of Early Intermediates in the Bacteriorhodopsin Photocycle
Shigehiko Hayashi, Emad Tajkhorshid, and Klaus Schulten
Biophys. J. 83, 1281–1297 (2002)

==================================================
Usage:

1) Add the line

RETK    Protein

to residuetypes.dat (either in the working directory or in share/gromacs/top/).

2) In your PDB file, rename the residue name of the lysine and of the retinal to RETK. The lysine 
and the retinal should also have the same residue number.

3) Put the amber99sb-star-ildn-retk.ff in the working directory.

3) Run pdb2gmx, e.g.

pdb2gmx -f retk+2res.gro -water tip3p [-vsite hydrogen]

And choose 1.

4) Do some stuff with it, e.g.
editconf -f conf.gro -o box.gro -bt cubic -d 1
grompp -f em -c box.gro && mdrun -v -c em.pdb

Have fun!
======================================================

