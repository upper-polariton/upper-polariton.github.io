# will disappear by version 1.0

from pymol.wizard.demo import DemoState

Demo=DemoState



