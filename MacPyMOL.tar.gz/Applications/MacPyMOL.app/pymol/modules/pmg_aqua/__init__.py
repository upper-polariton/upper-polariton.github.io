
import re
import sys
from glob import glob
import traceback
import string
import __builtin__

def start_plugins():
    startup_pattern = re.sub(r"[\/\\][^\/\\]*$","/startup/*.py*",__file__)
    raw_list = glob(startup_pattern)
    unique = {}
    for a in raw_list:
        unique[re.sub(r".*[\/\\]|\.py.*$","",a)] = 1
    for name in unique.keys():
        try:
            if name != "__init__":
                module_context = string.join(string.split(__name__,'.'))
                mod_name = module_context+".startup."+name
                __builtin__.__import__(mod_name)
                mod = sys.modules[mod_name]
                if hasattr(mod,'__init__'):
                    mod.__init__()
        except:
            suppress = 0
            # suppress error reporting when using old versions of Python
            if float(sys.version[0:3])<2.3:
                if( name in ['apbs_tools' ]):
                    suppress = 1
            if not suppress:
                print "Exception in plugin '%s' -- Traceback follows..."%name
                traceback.print_exc()
                print "Error: unable to initialize plugin '%s'."%name
               
