# PyMOL epymol.mae module

from dotmae import MAEReader, MAEReaderException
from pymol import cmd
from chempy import cpv
import string
import math
import copy

from pymol.cgo import *

def read_maestr(maestr,name,state=0,finish=1,discrete=1,quiet=1,zoom=-1):
    mr = MAEReader()
    list = mr.listFromStr(maestr)
    if len(list)>1:
        discrete = 1
    else:
        discrete = 0
    for mdl in list:
        cmd.load_model(mdl,name,discrete=discrete)
    
