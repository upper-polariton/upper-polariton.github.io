#!/bin/sh
echo ' ' 
echo '==============================================================='
echo 'Creating "../pymol" startup script with'
echo "PYMOL_PATH=`pwd`/pymol"
echo '==============================================================='
echo 'If you move MacPyMOL in the future, change directory "cd" into'
echo 'the application bundle after moving it and re-run "./setup.sh".'
echo '==============================================================='
echo 'You may now want to copy or link:'
echo "\"../pymol\"" 
echo 'to something like "/usr/local/bin/pymol"'
echo '==============================================================='
echo 'Enjoy!'
echo ' '
echo '#!/bin/sh' > ../pymol
echo '#' >> ../pymol
echo '# PyMOL startup script' >> ../pymol
echo '#' >> ../pymol
echo '# If you move the MacPyMOL application bundle, change directory' >> ../pymol
echo '# into the bundle and re-run ./setup.sh to create a new launch script.' >> ../pymol
echo '#' >> ../pymol
echo "PYMOL_PATH=`pwd`/pymol" >> ../pymol
echo '#' >> ../pymol
echo 'export PYMOL_PATH' >> ../pymol
echo "PYMOL_EXE=`pwd`/Contents/MacOS/MacPyMOL" >> ../pymol
echo 'exec $PYMOL_EXE "$@"' >> ../pymol
chmod 755 ../pymol



